<?php /* Static Name: Social Links */ ?>
<ul class="social">
	<?php 	
		$social_networks = array("facebook", "twitter", "google");
		for($i=0, $array_lenght=count($social_networks); $i<$array_lenght; $i++){
			if(of_get_option($social_networks[$i]) != "") {
				if ( $social_networks[$i] == 'google' ) {
					$title = 'google+';
				} else {
					$title = $social_networks[$i];
				}
				echo '<li><a href="'.of_get_option($social_networks[$i]).'" title="'.$title.'">'.$title.'</a></li>';
			};
		};
	?>
</ul>