<?php /* Static Name: Banners */ ?>
<ul class="header_banners clearfix">
	<li><a href="<?php echo of_get_option("banner_link_url_1"); ?>"><img src="<?php echo of_get_option('banner_img_url_1', '' ); ?>" alt=""></a></li>
	<li class="center"><a href="<?php echo of_get_option("banner_link_url_2"); ?>"><img src="<?php echo of_get_option('banner_img_url_2', '' ); ?>" alt=""></a></li>
	<li><a href="<?php echo of_get_option("banner_link_url_3"); ?>"><img src="<?php echo of_get_option('banner_img_url_3', '' ); ?>" alt=""></a></li>
</ul>